Steps to Install:

1. Make sure you update the .env file with the relavant credentials. 
2. Make sure Docker is running locally.
3. Once that is done, execute the following from the root: docker-compose up --build -d 
4. Above should setup the platform. You can access the system via localhost:3000.
5. For instructions how to use the platform, refer to the tutorial documents attached herewith. 
6. You can also follow the video demonstration playlist at: https://www.youtube.com/playlist?list=PL-wbcL0lihjDzvWDNHR4oFr7-7eNr-uf6 

Credentials in the .env:
1. You can use any preferable username and password respectively for MYSQL_ROOT_PASSWORD, MONGO_ROOT_USERNAME, MONGO_ROOT_PASSWORD, NEO4J_USERNAME, and NEO4J_PASSWORD. This will synchronize across all the containers where applicable. 
2. For OpenAI / LLM Configurations, we suggest setting atleast one API key. This API can be personal or organizational as long as it facilitates making calls to the taregt LLM. 
3. The value for ENCRYPTION_KEY can be literal of your choice. 
4. The ENCRYPTION_KEY should be a Base64 encoded 256-bit key that should be 44 characters long. If you want to generate one your self ONLY FOR TESTING, https://anycript.com/crypto would help with generating one. 