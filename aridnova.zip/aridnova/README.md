Steps to Install:

1. Make sure you update the .env file with the relavant credentials. 
2. Make sure Docker is running locally.
3. Once that is done, execute the following from the root: docker-compose up --build -d 
4. Above should setup the platform. You can access the system via localhost:3000.
5. For instructions how to use the platform, refer to the tutorial documents attached herewith. 
6. You can also follow the video demonstration playlist at: https://www.youtube.com/playlist?list=PL-wbcL0lihjDzvWDNHR4oFr7-7eNr-uf6 